# Copyright 2025 Aner Arregi - AvanzOSC
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from odoo import fields, models


class StockMove(models.Model):
    _inherit = "stock.move"

    peso_validado = fields.Boolean(
        default=False,
        tracking=True,
        help="Mark when the weight of the product has been physically verified.",
    )

    peso_validado_por = fields.Many2one(
        "res.users", string="Validated by", readonly=True, tracking=True
    )

    peso_validado_fecha = fields.Datetime(
        string="Validation date", readonly=True, tracking=True
    )

    def write(self, vals):
        if "validated_weight" in vals:
            vals.update(
                {
                    "weight_validated_by": self.env.user.id,
                    "weight_validated_day": fields.Datetime.now(),
                }
            )
        return super().write(vals)
